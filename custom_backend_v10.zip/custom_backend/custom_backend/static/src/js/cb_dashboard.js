/** @odoo-module **/
import { registry } from "@web/core/registry";
import { Component, onWillStart, useState, onWillUnmount } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

export class CbDashboard extends Component {
    static template = "custom_backend.CbDashboard";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");
        this.state = useState({ data: null, loading: true, error: null });
        onWillStart(async () => { await this.load(); });
        // auto-refresh tiap 30 detik
        this._timer = setInterval(() => this.load(), 30000);
        onWillUnmount(() => clearInterval(this._timer));
    }

    async load() {
        try {
            this.state.data = await this.orm.call("cb.dashboard", "get_dashboard", []);
            this.state.loading = false;
            this.state.error = null;
        } catch (e) {
            this.state.error = (e && e.message) || "load error";
            this.state.loading = false;
        }
    }
}

registry.category("actions").add("cb_dashboard", CbDashboard);
