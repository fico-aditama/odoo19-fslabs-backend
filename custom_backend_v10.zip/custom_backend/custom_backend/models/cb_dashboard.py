"""
Dashboard = living documentation + live data.
Tiap fitur: dokumentasi (apa & cara pakai) + statistik live.
"""
from datetime import datetime, time
from odoo import api, fields, models


class CbDashboard(models.AbstractModel):
    _name = "cb.dashboard"
    _description = "Custom Backend Dashboard"

    @api.model
    def get_dashboard(self):
        env = self.env
        Acc = env["cb.account"]; Msg = env["cb.message"]; Chat = env["cb.chat"]
        Contact = env["cb.contact"]
        today = fields.Date.today()
        dt0 = fields.Datetime.to_string(datetime.combine(today, time.min))

        def count(model, dom=None):
            return env[model].search_count(dom or [])

        # per-platform message breakdown
        plats = ["whatsapp", "telegram", "discord", "instagram", "threads", "email"]
        by_plat = []
        for p in plats:
            n = Msg.search_count([("platform", "=", p)])
            if n:
                by_plat.append({"label": p, "value": n})

        settings = env["cb.settings"].sudo().search([], limit=1)
        ai = env["cb.ai.config"].sudo().search([], limit=1)

        sections = [
            {
                "key": "accounts", "icon": "📱", "title": "Accounts",
                "doc": "Semua akun WhatsApp/Telegram/Discord/Instagram/Threads/Email di satu tempat. "
                       "Connect → scan QR (WA) / OTP (TG) / token (Discord) / login (IG) / IMAP (Email). "
                       "Tombol Re-sync untuk tarik ulang grup/kontak.",
                "stats": [
                    {"label": "Connected", "value": count("cb.account", [("status", "=", "connected")]), "tone": "ok"},
                    {"label": "Total", "value": count("cb.account")},
                    {"label": "Auth Fail", "value": count("cb.account", [("status", "=", "auth_failure")]), "tone": "bad"},
                ],
            },
            {
                "key": "messages", "icon": "💬", "title": "Messages",
                "doc": "Semua pesan lintas platform di satu model. WA terlengkap: media, lokasi, kontak, "
                       "polling, reply, forward, mention, reaction, read/unread, story, deleted, edit. "
                       "Filter per platform/tipe; toggle Exclude-from-AI per chat untuk privacy.",
                "stats": [
                    {"label": "Today", "value": Msg.search_count([("message_time", ">=", dt0)]), "tone": "ok"},
                    {"label": "Total", "value": count("cb.message")},
                    {"label": "Stories", "value": count("cb.message", [("is_story", "=", True)])},
                    {"label": "Deleted", "value": count("cb.message", [("is_deleted", "=", True)]), "tone": "warn"},
                ],
                "breakdown": by_plat,
            },
            {
                "key": "chats", "icon": "🗂️", "title": "Chats & Contacts",
                "doc": "Chat states (archived/pinned/muted/unread). Contacts dengan presence "
                       "(online/offline — detektif), about, foto, business. Identities = satukan kontak "
                       "lintas platform jadi 1 orang + export vCard.",
                "stats": [
                    {"label": "Chats", "value": count("cb.chat")},
                    {"label": "Contacts", "value": count("cb.contact")},
                    {"label": "Online", "value": count("cb.contact", [("presence", "=", "available")]), "tone": "ok"},
                    {"label": "Identities", "value": count("cb.identity")},
                ],
            },
            {
                "key": "ai", "icon": "🤖", "title": "AI & Assistant",
                "doc": "AI Summary rangkum pesan penting harian lintas platform (exclude chat privacy). "
                       "Assistant bot (Auto-Reply → Assistant Mode): chat 'remind me at 9...', 'summarize', dll. "
                       "Bisa pakai Agent eksternal (LangGraph + RAG ChromaDB + Langfuse + mem0 memory).",
                "stats": [
                    {"label": "Summaries", "value": count("cb.ai.summary")},
                    {"label": "Provider", "value": (ai.provider if ai else "-"), "text": True},
                    {"label": "Agent", "value": ("ON" if ai and ai.agent_enabled else "off"),
                     "tone": ("ok" if ai and ai.agent_enabled else "muted"), "text": True},
                    {"label": "Memory", "value": ("ON" if ai and ai.mem0_enabled else "off"),
                     "tone": ("ok" if ai and ai.mem0_enabled else "muted"), "text": True},
                ],
            },
            {
                "key": "autoreply", "icon": "↩️", "title": "Auto-Reply & Reminders",
                "doc": "Balas WA otomatis grounded Knowledge Base (8 lapis guard anti ngarang). "
                       "Mode Draft/Auto, whitelist, OOO, reply-on-tag di grup. "
                       "Reminders dari assistant terkirim ke WA pada waktunya.",
                "stats": [
                    {"label": "Rules", "value": count("cb.autoreply.rule", [("active", "=", True)]), "tone": "ok"},
                    {"label": "KB Entries", "value": count("cb.kb.entry")},
                    {"label": "Replies Today", "value": count("cb.autoreply.log", [("create_date", ">=", dt0)])},
                    {"label": "Reminders", "value": count("cb.reminder", [("state", "=", "scheduled")])},
                ],
            },
            {
                "key": "feeds", "icon": "📰", "title": "Feeds & Markets",
                "doc": "Monitor Google News/Medium/Jobstreet/Glints/LinkedIn + alert realtime ke WA. "
                       "Markets (Gold/Saham IDX/USD) multi-provider (Stooq/Twelve Data/Yahoo) + alert WA.",
                "stats": [
                    {"label": "Feed Sources", "value": count("cb.feed.source", [("active", "=", True)])},
                    {"label": "Feed Items", "value": count("cb.feed.item")},
                    {"label": "Symbols", "value": count("cb.market.symbol", [("active", "=", True)])},
                    {"label": "Mkt Provider", "value": (settings.market_provider if settings else "-"), "text": True},
                ],
            },
        ]

        health = {
            "bridge": (settings.bridge_health if settings else "unknown"),
            "accounts": (settings.bridge_accounts if settings else 0),
            "response_ms": (settings.response_ms if settings else 0),
            "last_check": str(settings.last_check) if settings and settings.last_check else "-",
        }
        return {
            "generated": fields.Datetime.to_string(fields.Datetime.now()),
            "health": health,
            "sections": sections,
        }
