import requests
from datetime import datetime
from odoo import api, fields, models


class CbSettings(models.Model):
    _name = "cb.settings"
    _description = "Custom Backend Settings"

    bridge_url    = fields.Char(string="Bridge URL", default="http://localhost:3000")
    bridge_secret = fields.Char(string="Bridge Secret")

    # ── monitoring ──
    bridge_health = fields.Selection([
        ("unknown", "Unknown"), ("up", "Up"), ("down", "Down"),
    ], default="unknown", readonly=True, string="Bridge Health")
    bridge_accounts = fields.Integer(string="Active Accounts (bridge)", readonly=True)
    last_check = fields.Datetime(readonly=True)
    last_error = fields.Char(readonly=True)
    response_ms = fields.Integer(string="Response (ms)", readonly=True)
    # ── Market data provider ──
    market_provider = fields.Selection([
        ("stooq", "Stooq (gratis, tanpa key) — rekomendasi"),
        ("twelvedata", "Twelve Data (free key, IDX bagus)"),
        ("yahoo", "Yahoo Finance (rawan 429)"),
    ], default="stooq", string="Market Provider")
    market_api_key = fields.Char(string="Market API Key", help="Untuk Twelve Data dll")
    # ── Alert email kalau bridge DOWN ──
    alert_email_enabled = fields.Boolean(string="Email Alert if Bridge Down")
    alert_email_account_id = fields.Many2one("cb.account", string="Send Via (Email Acct)",
                                             domain=[("platform", "=", "email")])
    alert_email_to = fields.Char(string="Alert Email To")
    _last_health_state = fields.Char(readonly=True)

    def action_health_check(self):
        for rec in self:
            rec._check()
        return True

    def _check(self):
        self.ensure_one()
        url = (self.bridge_url or "http://localhost:3000").rstrip("/") + "/health"
        t0 = datetime.now()
        try:
            resp = requests.get(url, timeout=8)
            ms = int((datetime.now() - t0).total_seconds() * 1000)
            if resp.status_code == 200:
                data = resp.json()
                self._last_health_state = "up"
                self.write({"bridge_health": "up",
                            "bridge_accounts": data.get("accounts", 0),
                            "last_check": fields.Datetime.now(),
                            "last_error": False, "response_ms": ms})
            else:
                self.write({"bridge_health": "down", "last_check": fields.Datetime.now(),
                            "last_error": f"HTTP {resp.status_code}", "response_ms": ms})
        except Exception as e:
            self.write({"bridge_health": "down", "bridge_accounts": 0,
                        "last_check": fields.Datetime.now(),
                        "last_error": str(e)[:200], "response_ms": 0})
        # alert email saat transisi ke DOWN
        self._maybe_alert_down()

    def _maybe_alert_down(self):
        if not self.alert_email_enabled or self.bridge_health != "down":
            self._last_health_state = self.bridge_health
            return
        if self._last_health_state == "down":
            return  # sudah dialert, jangan spam
        self._last_health_state = "down"
        if self.alert_email_account_id and self.alert_email_to:
            try:
                self.alert_email_account_id.email_send(
                    self.alert_email_to,
                    "[Custom Backend] Bridge DOWN",
                    f"Bridge tidak merespons.\nWaktu: {fields.Datetime.now()}\nError: {self.last_error or ''}")
            except Exception:
                pass

    @api.model
    def cron_health_check(self):
        s = self.search([], limit=1)
        if s:
            s._check()
