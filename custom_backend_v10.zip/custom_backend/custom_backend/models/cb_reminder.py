"""
Reminder + Assistant command engine.
Bot WA bisa terima perintah: remind, summarize, schedule, list reminders.
Reminder dikirim balik ke chat asal pada waktunya (cron).
"""
import re
from datetime import datetime, timedelta
from odoo import api, fields, models


class CbReminder(models.Model):
    _name = "cb.reminder"
    _description = "Reminder"
    _order = "remind_at asc"

    name = fields.Char(string="Reminder", required=True)
    account_id = fields.Many2one("cb.account", required=True, ondelete="cascade")
    chat_id = fields.Many2one("cb.chat", ondelete="set null")
    target_jid = fields.Char(string="Send To", required=True,
                             help="jid/nomor tujuan pengiriman reminder")
    remind_at = fields.Datetime(string="Remind At", required=True)
    state = fields.Selection([
        ("scheduled", "Scheduled"), ("sent", "Sent"),
        ("failed", "Failed"), ("cancelled", "Cancelled"),
    ], default="scheduled", index=True)
    source_text = fields.Char(string="Original Request")
    error = fields.Char()

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def _send_now(self):
        self.ensure_one()
        try:
            self.account_id.send_whatsapp(self.target_jid, f"⏰ Reminder: {self.name}")
            self.state = "sent"
        except Exception as e:
            self.state = "failed"
            self.error = str(e)[:200]

    @api.model
    def cron_fire(self):
        due = self.search([("state", "=", "scheduled"),
                           ("remind_at", "<=", fields.Datetime.now())], limit=50)
        for r in due:
            r._send_now()


class CbAssistant(models.AbstractModel):
    """Mesin perintah assistant. Dipanggil dari auto-reply kalau rule.assistant_mode."""
    _name = "cb.assistant"
    _description = "Assistant Command Engine"

    @api.model
    def handle(self, account, chat, msg):
        """Return string balasan, atau None kalau bukan command (lempar ke auto-reply biasa)."""
        text = (msg.message_text or "").strip()
        low = text.lower()

        # ── Agent (LangGraph/RAG) kalau diaktifkan ──
        cfg = self.env["cb.ai.config"]._get()
        if cfg.agent_enabled and cfg.agent_url:
            try:
                return self._handle_agent(cfg, account, chat, msg, text)
            except Exception:
                pass  # fallback ke parser regex di bawah

        # 1) REMINDER: "remind me at 9[:30] [pm] to X" / "ingetin jam 9 X"
        rem = self._parse_reminder(text, low)
        if rem:
            when, what = rem
            self.env["cb.reminder"].sudo().create({
                "name": what or "reminder",
                "account_id": account.id, "chat_id": chat.id,
                "target_jid": chat.chat_jid, "remind_at": when,
                "source_text": text,
            })
            return f"✅ Reminder set for {when:%Y-%m-%d %H:%M}: {what}"

        # 2) SUMMARIZE: "summarize" / "recap" / "rangkum"
        if any(k in low for k in ("summarize", "summary", "recap", "rangkum")):
            return self._summarize_today()

        # 3) LIST REMINDERS
        if any(k in low for k in ("my reminders", "list reminder", "reminder saya", "list pengingat")):
            return self._list_reminders(chat)

        # 4) HELP
        if low in ("help", "/help", "menu", "bantuan"):
            return ("🤖 Assistant commands:\n"
                    "• remind me at 9 to eat\n"
                    "• remind me at 14:30 call client\n"
                    "• summarize / recap (today's important messages)\n"
                    "• my reminders\n"
                    "Other questions answered from Knowledge Base.")

        return None  # bukan command → auto-reply biasa (KB/AI)

    @api.model
    def _handle_agent(self, cfg, account, chat, msg, text):
        # ambil history singkat chat ini
        recent = self.env["cb.message"].sudo().search(
            [("chat_id", "=", chat.id)], order="message_time desc", limit=10)
        history = [{"sender": m.sender_name or "", "text": m.message_text or "",
                    "is_from_me": m.is_from_me} for m in reversed(recent)]
        now = fields.Datetime.to_string(fields.Datetime.now())
        data = cfg.call_agent(text, history, now, session=account.bridge_token)
        reply = data.get("reply") or ""
        # eksekusi actions (reminder)
        for act in (data.get("actions") or []):
            if act.get("type") == "reminder" and act.get("remind_at"):
                self.env["cb.reminder"].sudo().create({
                    "name": act.get("text") or "reminder",
                    "account_id": account.id, "chat_id": chat.id,
                    "target_jid": chat.chat_jid, "remind_at": act["remind_at"],
                    "source_text": text,
                })
        return reply or None

    def _parse_reminder(self, text, low):
        # trigger
        if not any(k in low for k in ("remind", "ingetin", "ingatkan", "reminder")):
            return None
        now = fields.Datetime.now()
        when = None
        # jam HH:MM atau HH (+am/pm) — "at 9", "jam 9", "9:30 pm", "at 14:30"
        m = re.search(r'(?:at|jam|pukul)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?', low)
        if m:
            hh = int(m.group(1)); mm = int(m.group(2) or 0); ap = m.group(3)
            if ap == "pm" and hh < 12: hh += 12
            if ap == "am" and hh == 12: hh = 0
            base = now
            if "besok" in low or "tomorrow" in low:
                base = now + timedelta(days=1)
            try:
                when = base.replace(hour=hh, minute=mm, second=0, microsecond=0)
                if when <= now and not ("besok" in low or "tomorrow" in low):
                    when += timedelta(days=1)  # kalau jam udah lewat → besok
            except ValueError:
                when = None
        # "in N minutes/hours" / "N menit/jam lagi"
        if not when:
            m2 = re.search(r'(?:in\s*)?(\d{1,3})\s*(min|minute|menit)', low)
            m3 = re.search(r'(?:in\s*)?(\d{1,3})\s*(hour|jam)', low)
            if m2: when = now + timedelta(minutes=int(m2.group(1)))
            elif m3: when = now + timedelta(hours=int(m3.group(1)))
        if not when:
            return None
        # ekstrak "what": setelah to/untuk/buat, atau buang trigger+waktu
        what = text
        mw = re.search(r'(?:to|untuk|buat|supaya)\s+(.*)$', text, re.I)
        if mw:
            what = mw.group(1).strip()
        else:
            what = re.sub(r'(remind me|remind|ingetin|ingatkan|reminder|aku|saya)', '', what, flags=re.I)
            what = re.sub(r'(?:at|jam|pukul)\s*\d{1,2}(?::\d{2})?\s*(am|pm)?', '', what, flags=re.I).strip(" ,.")
        return when, (what or "reminder")

    def _summarize_today(self):
        from datetime import time as _t
        today = fields.Date.today()
        dt_from = datetime.combine(today, _t.min)
        msgs = self.env["cb.message"].search([
            ("message_time", ">=", fields.Datetime.to_string(dt_from)),
            ("chat_id.exclude_from_ai", "=", False),
            ("is_from_me", "=", False),
        ], order="message_time asc", limit=200)
        if not msgs:
            return "No messages to summarize today."
        cfg = self.env["cb.ai.config"]._get()
        lines = []
        for m in msgs:
            who = m.sender_name or "?"
            lines.append(f"[{m.platform}] {m.chat_name} — {who}: {(m.message_text or '')[:160]}")
        prompt = "Summarize today's important messages:\n\n" + "\n".join(lines[:200])
        try:
            return cfg._call_ai(prompt, system_prompt=cfg.summary_prompt)
        except Exception as e:
            return f"(Summary failed: {e})"

    def _list_reminders(self, chat):
        rems = self.env["cb.reminder"].sudo().search([
            ("chat_id", "=", chat.id), ("state", "=", "scheduled")], order="remind_at asc", limit=10)
        if not rems:
            return "No active reminders."
        out = ["⏰ Your reminders:"]
        for r in rems:
            out.append(f"• {r.remind_at:%Y-%m-%d %H:%M} — {r.name}")
        return "\n".join(out)
