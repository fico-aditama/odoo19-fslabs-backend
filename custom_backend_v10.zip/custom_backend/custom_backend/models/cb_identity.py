"""
Cross-platform Identity — satukan kontak dari WA/TG/Discord/IG/Threads/Email
jadi satu identitas orang. Export vCard (.vcf).
"""
import base64
from odoo import api, fields, models


class CbIdentity(models.Model):
    _name = "cb.identity"
    _description = "Cross-Platform Identity"
    _order = "name"

    name = fields.Char(string="Name", required=True)
    full_name = fields.Char(string="Full Name")
    organization = fields.Char(string="Organization")
    title = fields.Char(string="Title / Role")
    email = fields.Char(string="Primary Email")
    phone = fields.Char(string="Primary Phone")
    notes = fields.Text(string="Notes")
    tags = fields.Char(string="Tags")
    avatar = fields.Binary(string="Photo", attachment=True)
    active = fields.Boolean(default=True)

    contact_ids = fields.One2many("cb.contact", "identity_id", string="Linked Accounts")
    contact_count = fields.Integer(compute="_compute_agg", store=False)
    platform_summary = fields.Char(compute="_compute_agg", string="Platforms", store=False)
    handles = fields.Text(compute="_compute_agg", string="Handles", store=False)
    message_count = fields.Integer(compute="_compute_msg", string="Total Messages", store=False)

    @api.depends("contact_ids", "contact_ids.platform", "contact_ids.jid")
    def _compute_agg(self):
        for rec in self:
            rec.contact_count = len(rec.contact_ids)
            plats = []
            handles = []
            for c in rec.contact_ids:
                p = c.platform or "?"
                if p not in plats:
                    plats.append(p)
                handles.append(f"[{p}] {c.name or ''} <{c.jid}>")
            rec.platform_summary = ", ".join(plats)
            rec.handles = "\n".join(handles)

    def _compute_msg(self):
        Msg = self.env["cb.message"]
        for rec in self:
            total = 0
            for c in rec.contact_ids:
                total += Msg.search_count([
                    ("account_id", "=", c.account_id.id), ("sender_jid", "=", c.jid)])
            rec.message_count = total

    def action_view_messages(self):
        self.ensure_one()
        domain = ["|"] * (len(self.contact_ids) - 1) if len(self.contact_ids) > 1 else []
        for c in self.contact_ids:
            domain += ["&", ("account_id", "=", c.account_id.id), ("sender_jid", "=", c.jid)]
        if not self.contact_ids:
            domain = [("id", "=", False)]
        return {"type": "ir.actions.act_window", "name": f"Messages — {self.name}",
                "res_model": "cb.message", "view_mode": "list,form", "domain": domain}

    def _build_vcard(self):
        self.ensure_one()
        lines = ["BEGIN:VCARD", "VERSION:3.0"]
        lines.append(f"FN:{self.full_name or self.name}")
        if self.organization:
            lines.append(f"ORG:{self.organization}")
        if self.title:
            lines.append(f"TITLE:{self.title}")
        if self.phone:
            lines.append(f"TEL;TYPE=CELL:{self.phone}")
        if self.email:
            lines.append(f"EMAIL:{self.email}")
        # handle per platform → X- field
        XMAP = {"whatsapp": "X-WHATSAPP", "telegram": "X-TELEGRAM", "discord": "X-DISCORD",
                "instagram": "X-INSTAGRAM", "threads": "X-THREADS", "email": "EMAIL"}
        for c in self.contact_ids:
            key = XMAP.get(c.platform, "X-OTHER")
            lines.append(f"{key}:{c.jid}")
        if self.tags:
            lines.append(f"CATEGORIES:{self.tags}")
        if self.notes:
            lines.append("NOTE:" + (self.notes or "").replace("\n", "\\n"))
        lines.append("END:VCARD")
        return "\n".join(lines)

    def action_export_vcard(self):
        self.ensure_one()
        vcf = self._build_vcard()
        att = self.env["ir.attachment"].create({
            "name": f"{self.name}.vcf",
            "datas": base64.b64encode(vcf.encode("utf-8")),
            "mimetype": "text/vcard",
        })
        return {"type": "ir.actions.act_url",
                "url": f"/web/content/{att.id}?download=true", "target": "new"}

    @api.model
    def action_autolink_by_name(self):
        """Gabungkan kontak dengan nama sama (lintas platform) jadi satu identity."""
        Contact = self.env["cb.contact"]
        unlinked = Contact.search([("identity_id", "=", False), ("name", "!=", False)])
        groups = {}
        for c in unlinked:
            key = (c.name or "").strip().lower()
            if len(key) < 3:
                continue
            groups.setdefault(key, Contact.browse())
            groups[key] |= c
        created = 0
        for key, contacts in groups.items():
            if len(contacts) < 2:
                continue  # cuma link kalau ada 2+ kontak nama sama
            ident = self.create({"name": contacts[0].name})
            contacts.write({"identity_id": ident.id})
            created += 1
        return {"type": "ir.actions.client", "tag": "display_notification",
                "params": {"title": "Auto-Link", "type": "success",
                           "message": f"{created} identity dibuat dari kontak nama sama."}}
