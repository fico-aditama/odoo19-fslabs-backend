"""
AI config + provider router. Dipakai untuk summarize & auto-reply.
Support: OpenAI, Gemini, dan Custom endpoint (mis. FastAPI/LangChain sendiri).
"""
import json
import requests
from odoo import api, fields, models
from odoo.exceptions import UserError


class CbAiConfig(models.Model):
    _name = "cb.ai.config"
    _description = "AI Configuration"

    name = fields.Char(default="AI Config", readonly=True)
    enabled = fields.Boolean(string="Enabled", default=True)
    provider = fields.Selection([
        ("openai", "OpenAI"),
        ("gemini", "Google Gemini"),
        ("custom", "Custom Endpoint (FastAPI dll)"),
    ], default="openai", required=True, string="Provider")

    api_key = fields.Char(string="API Key", help="OpenAI/Gemini API key")
    model = fields.Char(string="Model", default="gpt-4o-mini",
                        help="openai: gpt-4o-mini / gpt-4o — gemini: gemini-2.0-flash")
    base_url = fields.Char(string="Custom Base URL",
                           help="Untuk provider custom: URL endpoint yang terima {prompt} dan balas {text}")
    temperature = fields.Float(string="Temperature", default=0.3)
    max_tokens = fields.Integer(string="Max Tokens", default=1024)

    summary_prompt = fields.Text(
        string="Summary System Prompt",
        default=("Kamu asisten yang merangkum percakapan chat. "
                 "Ringkas pesan-pesan PENTING hari ini per chat: keputusan, deadline, "
                 "permintaan, pertanyaan yang belum dijawab, dan info penting. "
                 "Abaikan basa-basi. Output ringkas, pakai bullet per chat, Bahasa Indonesia."))

    def _get(self):
        cfg = self.sudo().search([], limit=1)
        if not cfg:
            cfg = self.sudo().create({})
        return cfg

    def action_test(self):
        self.ensure_one()
        try:
            out = self._call_ai("Balas dengan satu kata: OK")
            return {
                "type": "ir.actions.client", "tag": "display_notification",
                "params": {"title": "AI Test", "message": f"Respons: {out[:200]}",
                           "type": "success", "sticky": False},
            }
        except Exception as e:
            raise UserError(f"AI test gagal: {e}")

    # ── PROVIDER ROUTER (dipakai ulang oleh summarize & auto-reply) ──
    def _call_ai(self, user_prompt, system_prompt=None):
        self.ensure_one()
        if not self.enabled:
            raise UserError("AI sedang disabled di config.")
        if self.provider == "openai":
            return self._call_openai(user_prompt, system_prompt)
        if self.provider == "gemini":
            return self._call_gemini(user_prompt, system_prompt)
        if self.provider == "custom":
            return self._call_custom(user_prompt, system_prompt)
        raise UserError("Provider tidak dikenal.")

    def _call_openai(self, user_prompt, system_prompt=None):
        if not self.api_key:
            raise UserError("OpenAI API key kosong.")
        msgs = []
        if system_prompt:
            msgs.append({"role": "system", "content": system_prompt})
        msgs.append({"role": "user", "content": user_prompt})
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}",
                     "Content-Type": "application/json"},
            json={"model": self.model or "gpt-4o-mini", "messages": msgs,
                  "temperature": self.temperature, "max_tokens": self.max_tokens},
            timeout=120)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()

    def _call_gemini(self, user_prompt, system_prompt=None):
        if not self.api_key:
            raise UserError("Gemini API key kosong.")
        model = self.model or "gemini-2.0-flash"
        url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
               f"{model}:generateContent?key={self.api_key}")
        parts = []
        if system_prompt:
            parts.append({"text": system_prompt + "\n\n"})
        parts.append({"text": user_prompt})
        resp = requests.post(url, json={
            "contents": [{"parts": parts}],
            "generationConfig": {"temperature": self.temperature,
                                 "maxOutputTokens": self.max_tokens},
        }, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()

    def _call_custom(self, user_prompt, system_prompt=None):
        if not self.base_url:
            raise UserError("Custom base_url kosong.")
        resp = requests.post(self.base_url.rstrip("/"), json={
            "prompt": user_prompt, "system": system_prompt or "",
            "model": self.model or "", "temperature": self.temperature,
        }, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        # terima beberapa kemungkinan bentuk respons
        return (data.get("text") or data.get("response")
                or data.get("content") or json.dumps(data))[:8000]
