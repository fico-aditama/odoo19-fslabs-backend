import secrets
import requests
from odoo import api, fields, models
from odoo.exceptions import UserError

PLATFORMS = [
    ("whatsapp",  "WhatsApp"),
    ("telegram",  "Telegram"),
    ("discord",   "Discord"),
    ("instagram", "Instagram"),
    ("threads",   "Threads"),
]


class CbAccount(models.Model):
    """Satu akun di salah satu platform. Pembeda: field `platform`."""
    _name = "cb.account"
    _description = "Social Account"
    _order = "platform, create_date desc"

    name = fields.Char(string="Label", required=True, default="Account")
    platform = fields.Selection(PLATFORMS, required=True, string="Platform", index=True)
    bridge_token = fields.Char(string="Bridge Token", readonly=True, copy=False)

    status = fields.Selection([
        ("disconnected",      "Disconnected"),
        ("connecting",        "Connecting"),
        ("waiting_qr",        "Waiting QR"),
        ("waiting_code",      "Waiting OTP/Code"),
        ("waiting_password",  "Waiting 2FA"),
        ("waiting_challenge", "Waiting Verification"),
        ("connected",         "Connected"),
        ("auth_failure",      "Auth Failure"),
    ], default="disconnected", readonly=True, string="Status")

    # credential fields (dipakai sesuai platform)
    phone        = fields.Char(string="Phone (TG/WA)")
    username     = fields.Char(string="Username/IG user")
    password     = fields.Char(string="Password (IG)")
    token_secret = fields.Char(string="Token (Discord/Threads)",
                               help="Discord user token / Threads access token")
    extra_config = fields.Char(string="Extra (Threads mode / scrape user)")

    # interactive login
    qr_code_data  = fields.Text(string="QR Data", readonly=True)
    qr_image      = fields.Binary(string="QR Image", readonly=True, attachment=True)
    login_code    = fields.Char(string="OTP / Verification Code")
    login_password= fields.Char(string="2FA Password")

    connected_at = fields.Datetime(readonly=True)
    last_ping    = fields.Datetime(readonly=True)
    bridge_log   = fields.Text(readonly=True)

    chat_count    = fields.Integer(compute="_compute_stats", string="Chats")
    message_count = fields.Integer(compute="_compute_stats", string="Messages")

    @api.depends("name")
    def _compute_stats(self):
        for rec in self:
            rec.chat_count    = self.env["cb.chat"].search_count([("account_id", "=", rec.id)])
            rec.message_count = self.env["cb.message"].search_count([("account_id", "=", rec.id)])

    # ── bridge ────────────────────────────────────────────────────────────────
    def _settings(self):
        return self.env["cb.settings"].sudo().search([], order="id asc", limit=1)

    def _call_bridge(self, path, data=None):
        s = self._settings()
        url = (s.bridge_url or "http://localhost:3000").rstrip("/") + path
        try:
            resp = requests.post(url, json={"bridge_secret": s.bridge_secret or "", **(data or {})}, timeout=60)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            raise UserError(f"Bridge tidak bisa dihubungi: {e}\nURL: {url}")

    def _connect_payload(self):
        """payload sesuai platform."""
        self.ensure_one()
        base = {"token": self.bridge_token, "platform": self.platform}
        if self.platform in ("whatsapp",):
            pass  # WA cuma butuh token (QR flow)
        elif self.platform == "telegram":
            base["phone"] = self.phone or ""
        elif self.platform == "discord":
            base["discord_token"] = self.token_secret or ""
        elif self.platform == "instagram":
            base["username"] = self.username or ""
            base["password"] = self.password or ""
        elif self.platform == "threads":
            base["mode"] = self.extra_config or "api"
            base["access_token"] = self.token_secret or ""
            base["scrape_user"] = self.username or ""
        return base

    def action_connect(self):
        for rec in self:
            if not rec.bridge_token:
                rec.bridge_token = secrets.token_urlsafe(32)
            rec.status = "connecting"
            rec.qr_code_data = False
            rec.qr_image = False
            rec._call_bridge("/cb/bridge/connect", rec._connect_payload())

    def action_submit_code(self):
        for rec in self:
            if not rec.login_code:
                raise UserError("Masukkan kode dulu.")
            rec._call_bridge("/cb/bridge/code", {
                "token": rec.bridge_token, "code": rec.login_code})
            rec.login_code = False

    def action_submit_password(self):
        for rec in self:
            if not rec.login_password:
                raise UserError("Masukkan password dulu.")
            rec._call_bridge("/cb/bridge/password", {
                "token": rec.bridge_token, "password": rec.login_password})
            rec.login_password = False

    def action_disconnect(self):
        for rec in self:
            if rec.bridge_token:
                try:
                    rec._call_bridge("/cb/bridge/disconnect", {"token": rec.bridge_token})
                except Exception:
                    pass
            rec.status = "disconnected"
            rec.qr_code_data = False
            rec.qr_image = False

    def action_refresh_log(self):
        for rec in self:
            if not rec.bridge_token:
                continue
            try:
                r = rec._call_bridge("/cb/bridge/logs", {"token": rec.bridge_token})
                rec.bridge_log = r.get("logs") or "(kosong)"
            except Exception as e:
                rec.bridge_log = f"Error: {e}"

    def action_view_chats(self):
        return {"type": "ir.actions.act_window", "name": "Chats",
                "res_model": "cb.chat", "view_mode": "list,form",
                "domain": [("account_id", "=", self.id)]}

    def action_view_messages(self):
        return {"type": "ir.actions.act_window", "name": "Messages",
                "res_model": "cb.message", "view_mode": "list,form",
                "domain": [("account_id", "=", self.id)]}

    @api.model
    def get_active_accounts(self):
        accs = self.search([("status", "not in", ["disconnected"]), ("bridge_token", "!=", False)])
        return [a._connect_payload() for a in accs]
