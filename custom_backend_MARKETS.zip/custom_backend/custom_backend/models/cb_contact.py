from odoo import api, fields, models


class CbContact(models.Model):
    _name = "cb.contact"
    _description = "Social Contact"
    _order = "name asc"

    account_id = fields.Many2one("cb.account", required=True, ondelete="cascade", index=True)
    platform   = fields.Selection(related="account_id.platform", store=True, index=True)
    jid  = fields.Char(string="ID", required=True, index=True)
    name = fields.Char(string="Name")

    _unique_contact = models.Constraint(
        "UNIQUE(account_id, jid)", "Contact unik per account.")

    @api.model
    def upsert(self, account, jid, name):
        c = self.sudo().search([("account_id", "=", account.id), ("jid", "=", jid)], limit=1)
        if not c:
            self.sudo().create({"account_id": account.id, "jid": jid, "name": name or jid})
        elif name and c.name != name:
            c.sudo().write({"name": name})
