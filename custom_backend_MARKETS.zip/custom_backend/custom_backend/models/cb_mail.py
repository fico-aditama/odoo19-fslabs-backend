"""
Mail: IMAP terima + SMTP reply dari Odoo. Native Python, no bridge.
Keamanan: WAJIB App Password. Tiap akun bisa di-disable independen.
"""
import imaplib
import smtplib
import email
from email.header import decode_header, make_header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
from odoo import api, fields, models
from odoo.exceptions import UserError


class CbMailAccount(models.Model):
    _name = "cb.mail.account"
    _description = "Mail Account (IMAP/SMTP)"
    _order = "create_date desc"

    name = fields.Char(required=True, default="Mail #1")
    email_address = fields.Char(string="Email", required=True)
    # IMAP
    imap_host = fields.Char(string="IMAP Host", required=True, default="imap.gmail.com")
    imap_port = fields.Integer(string="IMAP Port", default=993)
    imap_ssl  = fields.Boolean(string="IMAP SSL", default=True)
    folder    = fields.Char(default="INBOX")
    # SMTP (untuk reply)
    smtp_host = fields.Char(string="SMTP Host", default="smtp.gmail.com")
    smtp_port = fields.Integer(string="SMTP Port", default=587)
    smtp_tls  = fields.Boolean(string="SMTP TLS", default=True)
    # creds
    username  = fields.Char(required=True, help="biasanya = email")
    password  = fields.Char(required=True, help="⚠️ App Password, BUKAN password utama")

    active = fields.Boolean(default=True)
    fetch_limit = fields.Integer(string="Fetch Limit/Run", default=50)
    last_uid = fields.Char(readonly=True)
    status = fields.Selection([("idle","Idle"),("ok","OK"),("error","Error")],
                              default="idle", readonly=True)
    last_fetch = fields.Datetime(readonly=True)
    last_error = fields.Char(readonly=True)
    message_count = fields.Integer(compute="_compute_count")

    @api.depends("name")
    def _compute_count(self):
        for rec in self:
            rec.message_count = self.env["cb.mail.message"].search_count([("account_id","=",rec.id)])

    def _imap(self):
        self.ensure_one()
        conn = (imaplib.IMAP4_SSL(self.imap_host, self.imap_port) if self.imap_ssl
                else imaplib.IMAP4(self.imap_host, self.imap_port))
        conn.login(self.username, self.password)
        return conn

    def action_test(self):
        for rec in self:
            try:
                c = rec._imap(); c.select(rec.folder, readonly=True); c.logout()
                rec.write({"status":"ok","last_error":False})
            except Exception as e:
                rec.write({"status":"error","last_error":str(e)[:200]})
                raise UserError(f"IMAP gagal: {e}")
        return {"type":"ir.actions.client","tag":"display_notification",
                "params":{"message":"Koneksi OK!","type":"success"}}

    def _decode(self, v):
        if not v: return ""
        try: return str(make_header(decode_header(v)))
        except Exception: return str(v)

    def action_fetch(self):
        for rec in self: rec._fetch_one()

    def _fetch_one(self):
        self.ensure_one()
        try:
            c = self._imap(); c.select(self.folder, readonly=True)
            if self.last_uid:
                typ, data = c.uid("search", None, f"UID {int(self.last_uid)+1}:*")
            else:
                typ, data = c.uid("search", None, "ALL")
            uids = data[0].split() if data and data[0] else []
            uids = uids[-self.fetch_limit:] if len(uids) > self.fetch_limit else uids
            maxu = int(self.last_uid or 0); n = 0
            for uid in uids:
                us = uid.decode()
                typ, md = c.uid("fetch", uid, "(BODY.PEEK[])")
                if typ != "OK" or not md or not md[0]: continue
                msg = email.message_from_bytes(md[0][1])
                if self.env["cb.mail.message"].sudo().search(
                        [("account_id","=",self.id),("uid","=",us)], limit=1):
                    continue
                self.env["cb.mail.message"].sudo().create(self._parse(msg, us))
                n += 1
                if int(us) > maxu: maxu = int(us)
            c.logout()
            self.write({"status":"ok","last_fetch":fields.Datetime.now(),
                        "last_error":False,"last_uid":str(maxu) if maxu else self.last_uid})
            return n
        except Exception as e:
            self.write({"status":"error","last_error":str(e)[:200]})
            return 0

    def _parse(self, msg, uid):
        body = ""; has_att = False
        if msg.is_multipart():
            for part in msg.walk():
                disp = str(part.get("Content-Disposition") or "")
                if "attachment" in disp: has_att = True; continue
                if part.get_content_type() == "text/plain" and not body:
                    try: body = part.get_payload(decode=True).decode(
                        part.get_content_charset() or "utf-8", errors="replace")
                    except Exception: pass
        else:
            try: body = msg.get_payload(decode=True).decode(
                msg.get_content_charset() or "utf-8", errors="replace")
            except Exception: body = str(msg.get_payload())
        try:
            dt = email.utils.parsedate_to_datetime(msg.get("Date"))
            mt = dt.strftime("%Y-%m-%d %H:%M:%S") if dt else None
        except Exception: mt = None
        return {
            "account_id": self.id, "uid": uid,
            "message_id": msg.get("Message-ID") or uid,
            "subject": self._decode(msg.get("Subject")),
            "email_from": self._decode(msg.get("From")),
            "email_to": self._decode(msg.get("To")),
            "email_cc": self._decode(msg.get("Cc")),
            "body": body[:50000], "has_attachment": has_att, "message_time": mt,
        }

    def send_mail(self, to_addr, subject, body, in_reply_to=None):
        """Kirim email via SMTP (dipakai reply)."""
        self.ensure_one()
        m = MIMEText(body, "plain", "utf-8")
        m["From"] = formataddr((self.name, self.email_address))
        m["To"] = to_addr
        m["Subject"] = subject
        if in_reply_to:
            m["In-Reply-To"] = in_reply_to
            m["References"] = in_reply_to
        try:
            if self.smtp_tls:
                s = smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=30)
                s.starttls()
            else:
                s = smtplib.SMTP_SSL(self.smtp_host, self.smtp_port, timeout=30)
            s.login(self.username, self.password)
            s.sendmail(self.email_address, [to_addr], m.as_string())
            s.quit()
            return True
        except Exception as e:
            raise UserError(f"SMTP gagal kirim: {e}")

    @api.model
    def cron_fetch_all(self):
        for acc in self.search([("active","=",True)]):
            acc._fetch_one()

    def action_view_messages(self):
        return {"type":"ir.actions.act_window","name":"Emails",
                "res_model":"cb.mail.message","view_mode":"list,form",
                "domain":[("account_id","=",self.id)]}


class CbMailMessage(models.Model):
    _name = "cb.mail.message"
    _description = "Mail Message"
    _order = "message_time desc, id desc"
    _rec_name = "subject"

    account_id = fields.Many2one("cb.mail.account", required=True, ondelete="cascade", index=True)
    uid = fields.Char(index=True)
    message_id = fields.Char(index=True)
    subject = fields.Char()
    email_from = fields.Char()
    email_to = fields.Char()
    email_cc = fields.Char()
    body = fields.Text()
    has_attachment = fields.Boolean()
    message_time = fields.Datetime(index=True)
    # reply
    reply_text = fields.Text(string="Reply")
    replied = fields.Boolean(string="Replied", readonly=True)

    _unique_uid = models.Constraint("UNIQUE(account_id, uid)", "Duplicate email.")

    def action_send_reply(self):
        self.ensure_one()
        if not self.reply_text:
            raise UserError("Tulis balasan dulu.")
        from_name, from_addr = parseaddr(self.email_from or "")
        if not from_addr:
            raise UserError("Alamat pengirim tidak terbaca.")
        subj = self.subject or ""
        if not subj.lower().startswith("re:"):
            subj = "Re: " + subj
        self.account_id.send_mail(from_addr, subj, self.reply_text, in_reply_to=self.message_id)
        self.replied = True
        return {"type":"ir.actions.client","tag":"display_notification",
                "params":{"message":f"Balasan terkirim ke {from_addr}","type":"success"}}
