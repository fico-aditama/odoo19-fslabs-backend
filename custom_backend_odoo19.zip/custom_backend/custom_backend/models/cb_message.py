from odoo import api, fields, models


class CbMessage(models.Model):
    """SEMUA pesan dari semua platform. Pembeda: platform + message_type."""
    _name = "cb.message"
    _description = "Social Message"
    _order = "message_time desc, id desc"
    _rec_name = "message_text"

    account_id = fields.Many2one("cb.account", required=True, ondelete="cascade", index=True)
    platform   = fields.Selection(related="account_id.platform", store=True, index=True)
    chat_id    = fields.Many2one("cb.chat", required=True, ondelete="cascade", index=True)
    chat_name  = fields.Char(related="chat_id.name", store=True)
    chat_type  = fields.Selection(related="chat_id.chat_type", store=True)

    ext_message_id = fields.Char(string="Platform Message ID", index=True)
    sender_jid  = fields.Char(string="Sender ID")
    sender_name = fields.Char(string="Sender")
    is_from_me  = fields.Boolean(string="Sent by Me", default=False)
    is_edited   = fields.Boolean(string="Edited", default=False)

    message_text = fields.Text(string="Message")
    message_type = fields.Selection([
        ("text", "Text"), ("image", "Image"), ("video", "Video"),
        ("audio", "Audio"), ("document", "Document"), ("sticker", "Sticker"),
        ("location", "Location"), ("poll", "Poll"), ("system", "System"),
        ("other", "Other"),
    ], default="text", string="Type")
    message_time = fields.Datetime(string="Time", required=True, index=True)

    # attachment (universal)
    attachment_url      = fields.Char(string="Attachment URL")
    attachment_data     = fields.Binary(string="Attachment", attachment=True)
    attachment_mime     = fields.Char(string="MIME")
    attachment_filename = fields.Char(string="Filename")
    has_attachment      = fields.Boolean(compute="_compute_has_att", store=True)

    quoted_text_preview = fields.Char(string="Quoted")
    permalink           = fields.Char(string="Permalink")

    _unique_msg = models.Constraint(
        "UNIQUE(account_id, ext_message_id)", "Duplicate message per account.")

    @api.depends("attachment_url", "attachment_data")
    def _compute_has_att(self):
        for rec in self:
            rec.has_attachment = bool(rec.attachment_url or rec.attachment_data)

    @api.model
    def record_message(self, payload):
        account = self.env["cb.account"].sudo().search(
            [("bridge_token", "=", payload.get("session_token"))], limit=1)
        if not account:
            return {"error": "invalid_token"}

        chat_jid = payload.get("chat_jid")
        if not chat_jid:
            return {"error": "no_chat_jid"}

        chat = self.env["cb.chat"].sudo().search(
            [("account_id", "=", account.id), ("chat_jid", "=", chat_jid)], limit=1)
        chat_name = payload.get("chat_name") or chat_jid
        chat_type = payload.get("chat_type") or "dm"
        if not chat:
            chat = self.env["cb.chat"].sudo().create({
                "account_id": account.id, "chat_jid": chat_jid,
                "name": chat_name, "chat_type": chat_type,
            })
        elif chat_name and chat.name != chat_name:
            chat.sudo().write({"name": chat_name})

        if not chat.is_recording:
            return {"status": "skipped"}

        ext_id = payload.get("ext_message_id")
        existing = self.sudo().search(
            [("account_id", "=", account.id), ("ext_message_id", "=", ext_id)], limit=1)
        if existing:
            if payload.get("is_edited"):
                existing.sudo().write({
                    "message_text": payload.get("message_text"), "is_edited": True})
                return {"status": "updated", "id": existing.id}
            return {"status": "duplicate", "id": existing.id}

        vals = {
            "account_id": account.id, "chat_id": chat.id,
            "ext_message_id": ext_id,
            "sender_jid": payload.get("sender_jid"),
            "sender_name": payload.get("sender_name"),
            "is_from_me": payload.get("is_from_me", False),
            "is_edited": payload.get("is_edited", False),
            "message_type": payload.get("message_type", "text"),
            "message_text": payload.get("message_text"),
            "message_time": payload.get("message_time"),
            "attachment_url": payload.get("attachment_url"),
            "attachment_mime": payload.get("attachment_mime"),
            "attachment_filename": payload.get("attachment_filename"),
            "quoted_text_preview": payload.get("quoted_text_preview"),
            "permalink": payload.get("permalink"),
        }
        if payload.get("attachment_data"):
            vals["attachment_data"] = payload["attachment_data"]

        msg = self.sudo().create(vals)
        chat.sudo().write({
            "last_message_at": vals["message_time"],
            "last_message_preview": (vals.get("message_text") or f"[{vals['message_type']}]")[:80],
        })
        return {"status": "ok", "id": msg.id}
