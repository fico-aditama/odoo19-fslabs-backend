from odoo import fields, models


class CbSettings(models.Model):
    _name = "cb.settings"
    _description = "Custom Backend Settings"

    bridge_url    = fields.Char(string="Bridge URL", default="http://localhost:3000")
    bridge_secret = fields.Char(string="Bridge Secret")
