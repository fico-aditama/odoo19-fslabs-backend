{
    "name": "Custom Backend — Social Media Recorder",
    "version": "19.0.1.0.0",
    "summary": "Unified recorder: WhatsApp, Telegram, Discord, Instagram, Threads in ONE module",
    "category": "Discuss",
    "license": "LGPL-3",
    "author": "Custom",
    "depends": ["base", "web", "mail"],
    "data": [
        "security/ir.model.access.csv",
        "data/cb_settings_data.xml",
        "data/cb_cron.xml",
        "views/cb_account_views.xml",
        "views/cb_chat_views.xml",
        "views/cb_message_views.xml",
        "views/cb_contact_views.xml",
        "views/cb_settings_views.xml",
        "views/cb_menu.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "custom_backend/static/src/scss/cb.scss",
        ],
    },
    "application": True,
    "installable": True,
}
